function deep_copy(obj) {
  const res_object = {};       //выводимый объект, пока без свойств
  for(const i in obj) {        //в цикле по всем свойствам объекта
    if (obj[i] instanceof Object) { //если текущее свойство - тоже объект
      res_object[i] = deep_copy(obj[i]); //вызываем рекурсивно эту функцию от данного свойства
    }
    res_object[i] = obj[i]; //Присваиваем результивному объекту полученное свойство
  }
  return res_object; //результат функции - результивный объект
}

//пример использования функции

const X = {
  a: 1,
  b: { c: 2, d: { e: 3, f: 4}},
  g: { h: { i: {k: {l: 5, m: 6}, n: 7}, o: 8}, p: 9},
  r: 10,
  s: {t: 11, u: 12, v: {w: 13}, x: 14}
};

const Y = deep_copy(X)

console.log('X:', X);
console.log('Y:', Y);

Y.z = 'Ещё одно свойство, только для Y'

console.log('X:', X);
console.log('Y:', Y);