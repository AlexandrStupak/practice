function main () {
  const panelsElements = document.querySelector('.wrapper')
  const panel = new Panel()
  panel.click()
}

class Panel {
  click(){
    document.addEventListener('click', function(event) { //добавляем событие на клик в виде функции
      if (event.target.dataset.click != undefined) { 
        event.target.dataset.value++
        const val = event.target.dataset.value
        if (event.target.className == 'red') {
          document.getElementsByClassName('red-counter')[0].innerHTML = val
        } else if (event.target.className == 'green') {
        document.getElementsByClassName('green-counter')[0].innerHTML = val
        } else if (event.target.className == 'blue'){
        document.getElementsByClassName('blue-counter')[0].innerHTML = val
        }
      }
	})
  }
}

window.onload = main